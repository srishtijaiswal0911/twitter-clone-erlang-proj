-module(unuseddep).

-export([unuseddep/0]).

unuseddep() ->
    unuseddep.
