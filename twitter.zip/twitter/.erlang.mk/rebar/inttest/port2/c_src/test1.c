#include "test1.h"

#ifndef TEST1
#error TEST1 is not defined!
#endif

#ifndef TEST2
#error TEST2 is not defined!
#endif

#ifndef TEST3
#error TEST3 is not defined!
#endif
