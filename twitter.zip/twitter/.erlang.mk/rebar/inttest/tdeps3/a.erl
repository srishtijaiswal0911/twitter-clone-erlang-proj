-module({{module}}).

-include_lib("{{dep}}/include/{{dep}}.hrl").
