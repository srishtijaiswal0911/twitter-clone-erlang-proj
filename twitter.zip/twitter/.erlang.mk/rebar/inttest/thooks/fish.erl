-module(fish).

-compile(export_all).

fish() -> fish.
